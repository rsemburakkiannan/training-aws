package com.example.sanitizer;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * A custom layout that sanitizes log messages.
 */
public class SanitizingLayout extends PatternLayout {
    private final LogSanitizer sanitizer = new LogSanitizer();

    @Override
    public String doLayout(ILoggingEvent event) {
        String original = super.doLayout(event);
        return sanitizer.sanitize(original);
    }
}
