package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainApp {
    private static final Logger logger = LoggerFactory.getLogger(MainApp.class);

    public static void main(String[] args) {
        // Sample log messages containing various PII examples
        logger.info("User email: john.doe@example.com");
        logger.info("SSN: 123-45-6789");
        logger.info("Phone: +1-800-555-1234");
    }
}
