package com.example.sanitizer;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogSanitizer {
    private final MaskingConfig config;

    public LogSanitizer() {
        config = new MaskingConfig();
    }

    /**
     * Masks sensitive information in the input message.
     *
     * @param message The original log message.
     * @return The sanitized log message.
     */
    public String sanitize(String message) {
        String sanitizedMessage = message;
        Map<String, Pattern> patternMap = config.getPatternMap();
        for (Map.Entry<String, Pattern> entry : patternMap.entrySet()) {
            Pattern pattern = entry.getValue();
            Matcher matcher = pattern.matcher(sanitizedMessage);
            StringBuffer sb = new StringBuffer();
            while (matcher.find()) {
                String matchedText = matcher.group();
                String masked = maskText(matchedText);
                matcher.appendReplacement(sb, masked);
            }
            matcher.appendTail(sb);
            sanitizedMessage = sb.toString();
        }
        return sanitizedMessage;
    }

    /**
     * Masks the given text except for the last n characters.
     */
    private String maskText(String text) {
        int preserve = config.getPreserveChars();
        if (text.length() <= preserve) {
            return text;
        }
        int maskLength = text.length() - preserve;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < maskLength; i++) {
            sb.append(config.getMaskChar());
        }
        sb.append(text.substring(maskLength));
        return sb.toString();
    }
}
