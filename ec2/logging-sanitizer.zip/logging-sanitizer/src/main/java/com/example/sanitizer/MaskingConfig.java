package com.example.sanitizer;

import java.io.InputStream;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.HashMap;

public class MaskingConfig {
    private Map<String, Pattern> patternMap = new HashMap<>();
    private int preserveChars = 4; // default preserve last 4 characters
    private char maskChar = '*';   // default mask character

    public MaskingConfig() {
        loadProperties();
    }

    private void loadProperties() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("pii-patterns.properties")) {
            Properties props = new Properties();
            props.load(is);
            // Configuration entries for PII regex patterns, example keys: "creditcard", "ssn", etc.
            for (String key : props.stringPropertyNames()) {
                if (key.startsWith("pattern.")) {
                    String name = key.substring("pattern.".length());
                    String regex = props.getProperty(key);
                    patternMap.put(name, Pattern.compile(regex));
                }
            }
            // Optionally override default masking settings
            if (props.containsKey("masking.preserveChars")) {
                preserveChars = Integer.parseInt(props.getProperty("masking.preserveChars"));
            }
            if (props.containsKey("masking.maskChar")) {
                maskChar = props.getProperty("masking.maskChar").charAt(0);
            }
        } catch (Exception e) {
            System.err.println("Error loading masking configuration: " + e.getMessage());
        }
    }

    public Map<String, Pattern> getPatternMap() {
        return patternMap;
    }

    public int getPreserveChars() {
        return preserveChars;
    }

    public char getMaskChar() {
        return maskChar;
    }
}
