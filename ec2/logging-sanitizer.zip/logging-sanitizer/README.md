# Logging Sanitizer

## Overview
This project provides a framework-agnostic solution to sanitize logs automatically for Java applications using SLF4J/Logback and Log4J2. It reads configurable regex patterns from external properties files to mask sensitive PII such as emails, credit card numbers, SSNs, and phone numbers.

## Features
- **Framework-agnostic:** Works with SLF4J/Logback and Log4J2.
- **Externalized configuration:** Easily add/modify sensitive data patterns in `pii-patterns.properties`.
- **Configurable masking:** Preserve a configurable number of characters and choose a masking character.
- **Thread-safe:** Designed for use in multi-threaded environments.
- **Comprehensive coverage:** Applies to console output, file-based logging, and log aggregation systems.

## Project Structure
