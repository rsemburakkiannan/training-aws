package com.example.logging;

import org.apache.log4j.PatternLayout;
import org.apache.log4j.helpers.PatternParser;

/**
 * A custom PatternLayout that uses MaskingPatternParser to mask sensitive information in log messages.
 */
public class MaskingPatternLayout extends PatternLayout {

    public MaskingPatternLayout() {
        super();
    }

    /**
     * Constructor with a specified pattern.
     *
     * @param pattern the pattern to use for formatting log messages
     */
    public MaskingPatternLayout(String pattern) {
        super(pattern);
    }

    /**
     * Creates a PatternParser that uses MaskingPatternParser to parse the pattern.
     *
     * @param pattern the pattern to parse
     * @return a MaskingPatternParser instance
     */
    @Override
    protected PatternParser createPatternParser(String pattern) {
        return new MaskingPatternParser(pattern);
    }
}