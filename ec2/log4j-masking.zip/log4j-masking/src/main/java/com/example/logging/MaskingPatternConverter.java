package com.example.logging;

import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.spi.LoggingEvent;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

/**
 * A custom PatternConverter that masks sensitive information in log messages.
 */
public class MaskingPatternConverter extends PatternConverter {
    private static final Properties maskingPatterns = new Properties();
    private static int unmaskedLength = 4; // Default to 4 characters unmasked

    static {
        loadProperties("masking-patterns.properties", maskingPatterns);
        Properties config = new Properties();
        loadProperties("masking-config.properties", config);
        unmaskedLength = Integer.parseInt(config.getProperty("unmasked.length", "4"));
    }

    /**
     * Loads properties from a file into the provided Properties object.
     *
     * @param fileName the name of the properties file
     * @param properties the Properties object to load into
     */
    private static void loadProperties(String fileName, Properties properties) {
        try (InputStream input = MaskingPatternConverter.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input != null) {
                properties.load(input);
            } else {
                System.err.println("Failed to load " + fileName);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected String convert(LoggingEvent event) {
        if (event == null || event.getMessage() == null) {
            return null;
        }

        String logMessage = event.getRenderedMessage();

        for (String key : maskingPatterns.stringPropertyNames()) {
            String patternStr = maskingPatterns.getProperty(key);
            logMessage = maskPattern(logMessage, patternStr);
        }

        return logMessage;
    }

    /**
     * Masks all occurrences of the given pattern in the log message.
     *
     * @param logMessage the original log message
     * @param patternStr the regex pattern to match
     * @return the log message with masked values
     */
    private String maskPattern(String logMessage, String patternStr) {
        Pattern pattern = Pattern.compile(patternStr);
        Matcher matcher = pattern.matcher(logMessage);

        StringBuffer maskedMessage = new StringBuffer();
        while (matcher.find()) {
            String matchedValue = matcher.group();
            matcher.appendReplacement(maskedMessage, maskValue(matchedValue));
        }
        matcher.appendTail(maskedMessage);
        return maskedMessage.toString();
    }

    /**
     * Masks the given value, leaving the last unmaskedLength characters unmasked.
     *
     * @param value the value to mask
     * @return the masked value
     */
    private String maskValue(String value) {
        int length = value.length();
        if (length <= unmaskedLength) {
            return value; // If the length is smaller, do not mask
        }

        int maskLength = length - unmaskedLength;
        String maskedPart = "*".repeat(maskLength);
        String unmaskedPart = value.substring(maskLength);

        return maskedPart + unmaskedPart;
    }
}