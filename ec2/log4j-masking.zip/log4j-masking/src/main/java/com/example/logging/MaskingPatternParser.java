package com.example.logging;

import org.apache.log4j.helpers.PatternParser;

/**
 * A custom PatternParser that uses MaskingPatternConverter to mask sensitive information in log messages.
 */
public class MaskingPatternParser extends PatternParser {
    public MaskingPatternParser(String pattern) {
        super(pattern);
    }

    @Override
    protected void finalizeConverter(char c) {
        if (c == 'm') {
            currentLiteral.setLength(0);
            addConverter(new MaskingPatternConverter());
        } else {
            super.finalizeConverter(c);
        }
    }
}
