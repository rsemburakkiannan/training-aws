package com.example.app;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MainApp {
    private static final Logger logger = Logger.getLogger(MainApp.class);

    public static void main(String[] args) {
        // Configure log4j using the properties file
        PropertyConfigurator.configure(MainApp.class.getClassLoader()
                .getResource("log4j.properties"));

        // Log messages containing sensitive information
        logger.info("User SSN: 123-45-6789");
        logger.info("Credit Card Number: 4111-1111-1111-1111");
    }
}
